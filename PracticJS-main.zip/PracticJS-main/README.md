# PracticJS
Esta practica esta basada en un proyecto ya creado sobre Js
